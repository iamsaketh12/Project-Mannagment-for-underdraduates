<link rel="icon" type="image/x-icon" href="<?= BASE_URL; ?>assets/admin_login_home/images/favicon.png">
    <!-- Switcher CSS -->
    <link rel="stylesheet" href="<?= BASE_URL; ?>assets/admin_login_home/assets/plugin/switchery/switchery.min.css" />
    <!-- Morris CSS -->
    <link rel="stylesheet" href="<?= BASE_URL; ?>assets/admin_login_home/assets/plugin/morris/morris.css" />
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?= BASE_URL; ?>assets/admin_login_home/dist/css/style.css" />

     <link rel="stylesheet" href="<?= BASE_URL; ?>assets/admin_login_home/assets/plugin/datatable/datatables.min.css" />