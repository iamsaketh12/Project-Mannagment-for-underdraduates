<div class="menu-wrapper" style="background: linear-gradient(to right,#0acffe 0,#495aff 100%);">
    <div class="menu">
    <!-- Menu Container -->
       <ul>
            <li class="menu-title">Main</li>
            <li class="has-sub">
                <a style="color: aliceblue;">
                    <i class="icon-screen-desktop" ></i>
                    <span>Project</span>
                    <i class="arrow"></i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a href="project.php">
                            <span>View Project Details</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="has-sub">
                <a style="color: aliceblue;">
                    <i class="cc BTC"></i>
                    <span>Marks</span>
                    <i class="arrow"></i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a href="view_phase_marks.php">
                            <span>View Phase Marks</span>
                        </a>
                    </li> 
                </ul>
            </li>
        </ul>
    </div>
</div>