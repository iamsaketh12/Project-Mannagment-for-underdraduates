give images link
https://media.istockphoto.com/id/178609380/photo/making-necessary-notes.jpg?s=612x612&w=is&k=20&c=EFUS1oakY28-Uv4v1W5_ZRNPbDndF_othlwJLQWzb6s=